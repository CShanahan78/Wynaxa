"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";
import { useState } from "react";

export default function Investors() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    nda: false
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    alert("Thank you for your interest! We'll be in touch shortly.");
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-slate-900">Wynaxa</Link>

          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-slate-600 hover:text-slate-900 transition">About</Link>
            <Link href="/ecosystem" className="text-slate-600 hover:text-slate-900 transition">Ecosystem</Link>
            <Link href="/investors" className="text-slate-900 font-medium">Investors</Link>
            <Link href="/partners" className="text-slate-600 hover:text-slate-900 transition">Partners</Link>
            <Link href="/contact" className="text-slate-600 hover:text-slate-900 transition">Contact</Link>
          </div>

          <Button className="bg-emerald-600 hover:bg-emerald-700">
            Investor Access
          </Button>
        </div>
      </nav>

      {/* Header Banner */}
      <section className="py-24 px-6 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Invest in the Future,<br />Connected Locally.
          </h1>
          <p className="text-xl text-slate-300">
            We're redefining how local economies connect through socially responsible technology.
          </p>
        </div>
      </section>

      {/* Investment Highlights */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-16">
            Investment Highlights
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="hover-lift">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">🌍</span>
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4">Scalable Global Model</h3>
                <p className="text-slate-600">
                  Our ecosystem is designed to scale globally while maintaining deep local impact.
                  Proven success in multiple markets with clear expansion roadmap.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">💰</span>
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4">Community Reinvestment</h3>
                <p className="text-slate-600">
                  Unique model that keeps fees local, creating sustainable revenue
                  streams while driving unprecedented community engagement.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">🤝</span>
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4">Strategic Partnerships</h3>
                <p className="text-slate-600">
                  Strong government and fintech partnerships providing regulatory
                  support and market validation across key regions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Impact + Returns Graphic */}
      <section className="py-24 px-6 bg-gradient-to-br from-emerald-50 to-blue-50">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-12">
            How £1 Circulates in the Community
          </h2>

          <div className="bg-white rounded-3xl p-12 shadow-xl">
            <div className="space-y-8">
              <div className="flex items-center gap-6">
                <div className="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center text-white font-bold text-xl flex-shrink-0">
                  1
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">Initial Transaction</h3>
                  <p className="text-slate-600">Local business receives payment through Wynaxa Pay</p>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-xl flex-shrink-0">
                  2
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">Fees Stay Local</h3>
                  <p className="text-slate-600">Transaction fees go into community investment pool</p>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-xl flex-shrink-0">
                  3
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">Community Decides</h3>
                  <p className="text-slate-600">Local members vote on how to invest accumulated funds</p>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-xl flex-shrink-0">
                  4
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">Local Impact Multiplied</h3>
                  <p className="text-slate-600">Investments create jobs, infrastructure, and economic growth</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Request Access Form */}
      <section className="py-24 px-6 bg-slate-900 text-white">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Request Investor Access</h2>
            <p className="text-xl text-slate-300">
              Get exclusive access to our full investment materials, pitch deck,
              and financial projections.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-8 text-slate-900">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Full Name *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="John Smith"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Email Address *</label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="john@company.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Company / Fund Name *</label>
                <input
                  type="text"
                  required
                  value={formData.company}
                  onChange={(e) => setFormData({...formData, company: e.target.value})}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="Investment Partners Ltd"
                />
              </div>

              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  required
                  checked={formData.nda}
                  onChange={(e) => setFormData({...formData, nda: e.target.checked})}
                  className="mt-1 w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                />
                <label className="text-sm text-slate-600">
                  I acknowledge and agree to the NDA terms. All investment materials
                  are confidential and for authorized investors only.
                </label>
              </div>

              <Button type="submit" size="lg" className="w-full bg-emerald-600 hover:bg-emerald-700">
                Submit Access Request
              </Button>
            </div>
          </form>

          <p className="text-center text-slate-400 mt-8">
            Our team typically responds within 24-48 hours. For urgent inquiries,
            email <a href="mailto:investors@wynaxa.com" className="text-emerald-400 hover:underline">investors@wynaxa.com</a>
          </p>
        </div>
      </section>

      {/* Why Invest */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-16">
            Why Invest in Wynaxa?
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">✓</span>
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">First-Mover Advantage</h3>
                <p className="text-slate-600">
                  Pioneering the community-powered payments category with proprietary technology
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">✓</span>
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Proven Traction</h3>
                <p className="text-slate-600">
                  2,800+ businesses, 156 communities, £4.2M local impact generated
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">✓</span>
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Strong Network Effects</h3>
                <p className="text-slate-600">
                  Each new community and business amplifies the value of the entire ecosystem
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">✓</span>
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Impact + Returns</h3>
                <p className="text-slate-600">
                  Generate competitive returns while creating measurable positive social impact
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 bg-slate-950 text-slate-400">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex flex-wrap justify-center gap-6 mb-6">
            <Link href="/about" className="hover:text-white transition">About</Link>
            <Link href="/ecosystem" className="hover:text-white transition">Ecosystem</Link>
            <Link href="/investors" className="hover:text-white transition">Investors</Link>
            <Link href="/partners" className="hover:text-white transition">Partners</Link>
            <Link href="/contact" className="hover:text-white transition">Contact</Link>
          </div>
          <div className="text-sm">
            © 2025 Wynaxa. All rights reserved. | Privacy Policy | Terms of Service
          </div>
        </div>
      </footer>
    </div>
  );
}
