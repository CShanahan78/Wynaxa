"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";
import { useState, useEffect } from "react";

export default function Home() {
  const [count, setCount] = useState({ businesses: 0, communities: 0, funds: 0, carbon: 0 });

  useEffect(() => {
    const timer = setInterval(() => {
      setCount(prev => ({
        businesses: prev.businesses < 2847 ? prev.businesses + 47 : 2847,
        communities: prev.communities < 156 ? prev.communities + 3 : 156,
        funds: prev.funds < 4200000 ? prev.funds + 70000 : 4200000,
        carbon: prev.carbon < 18500 ? prev.carbon + 300 : 18500,
      }));
    }, 50);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Sticky Navigation */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="text-2xl font-bold text-slate-900">Wynaxa</div>

          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-slate-600 hover:text-slate-900 transition">About</Link>
            <Link href="/ecosystem" className="text-slate-600 hover:text-slate-900 transition">Ecosystem</Link>
            <Link href="/products" className="text-slate-600 hover:text-slate-900 transition">Products</Link>
            <Link href="/investors" className="text-slate-600 hover:text-slate-900 transition">Investors</Link>
            <Link href="/careers" className="text-slate-600 hover:text-slate-900 transition">Careers</Link>
            <Link href="/contact" className="text-slate-600 hover:text-slate-900 transition">Contact</Link>
          </div>

          <Link href="/investor-access">
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              Investor Access
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Animated gradient background */}
        <div className="absolute inset-0 gradient-bg opacity-20"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/50 to-white"></div>

        <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
          <h1 className="text-6xl md:text-7xl font-bold text-slate-900 mb-6">
            The Future,<br />Connected Locally.
          </h1>
          <p className="text-xl md:text-2xl text-slate-600 mb-12 max-w-3xl mx-auto">
            Empowering communities through technology that redefines how we connect, pay, and grow.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-slate-900 hover:bg-slate-800 text-white">
              Explore Our World
            </Button>
            <Link href="/investor-access">
              <Button size="lg" variant="outline" className="border-slate-900 text-slate-900 hover:bg-slate-100">
                Investor Access
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Ecosystem Preview */}
      <section className="py-24 px-6 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">
              The Wynaxa Ecosystem
            </h2>
            <p className="text-xl text-slate-600">
              Four products, one connected mission
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {/* Pay */}
            <Card className="hover-lift cursor-pointer border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-white">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">💳</span>
                </div>
                <h3 className="text-2xl font-bold text-purple-900 mb-3">Pay</h3>
                <p className="text-purple-700">
                  Smart local payments with transparent fees and community reinvestment
                </p>
              </CardContent>
            </Card>

            {/* One */}
            <Card className="hover-lift cursor-pointer border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">🏪</span>
                </div>
                <h3 className="text-2xl font-bold text-blue-900 mb-3">One</h3>
                <p className="text-blue-700">
                  Unified marketplace for local living, hospitality, and experiences
                </p>
              </CardContent>
            </Card>

            {/* Eco */}
            <Card className="hover-lift cursor-pointer border-2 border-green-200 bg-gradient-to-br from-green-50 to-white">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">🌱</span>
                </div>
                <h3 className="text-2xl font-bold text-green-900 mb-3">Eco</h3>
                <p className="text-green-700">
                  Circular economy support with rewards for sustainable choices
                </p>
              </CardContent>
            </Card>

            {/* Foundry */}
            <Card className="hover-lift cursor-pointer border-2 border-orange-200 bg-gradient-to-br from-orange-50 to-white">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">🔬</span>
                </div>
                <h3 className="text-2xl font-bold text-orange-900 mb-3">Foundry</h3>
                <p className="text-orange-700">
                  Incubating technology for good, from concept to community rollout
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <Button size="lg" variant="outline" className="border-slate-900 text-slate-900 hover:bg-slate-100">
              Explore the Wynaxa Ecosystem →
            </Button>
          </div>
        </div>
      </section>

      {/* Impact Stats Bar */}
      <section className="py-16 px-6 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-emerald-400 mb-2">
                {count.businesses.toLocaleString()}
              </div>
              <div className="text-slate-300">Businesses Empowered</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-400 mb-2">
                {count.communities}
              </div>
              <div className="text-slate-300">Communities Connected</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-purple-400 mb-2">
                £{(count.funds / 1000000).toFixed(1)}M
              </div>
              <div className="text-slate-300">Local Funds Reinvested</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-green-400 mb-2">
                {count.carbon.toLocaleString()}t
              </div>
              <div className="text-slate-300">Carbon Saved</div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Block */}
      <section className="py-24 px-6 bg-gradient-to-br from-slate-50 via-emerald-50 to-blue-50">
        <div className="max-w-4xl mx-auto text-center">
          <blockquote className="text-3xl md:text-4xl font-light text-slate-800 leading-relaxed mb-8">
            "Technology should bring people closer, not drive them apart. Wynaxa builds tools for local connection, not corporate extraction."
          </blockquote>
          <div className="w-24 h-1 bg-emerald-600 mx-auto"></div>
        </div>
      </section>

      {/* CTA Footer Section */}
      <section className="py-24 px-6 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="text-center md:text-left">
              <h3 className="text-3xl font-bold mb-4">Invest in the Future</h3>
              <p className="text-slate-300 mb-6">
                Join us in building technology that creates lasting positive impact for communities worldwide.
              </p>
              <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700">
                View Investment Opportunities →
              </Button>
            </div>

            <div className="text-center md:text-left">
              <h3 className="text-3xl font-bold mb-4">Partner with Us</h3>
              <p className="text-slate-300 mb-6">
                Collaborate with Wynaxa to bring sustainable, community-first technology to your region.
              </p>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-slate-900">
                Explore Partnerships →
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 bg-slate-950 text-slate-400">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex flex-wrap justify-center gap-6 mb-6">
            <Link href="/about" className="hover:text-white transition">About</Link>
            <Link href="/ecosystem" className="hover:text-white transition">Ecosystem</Link>
            <Link href="/products" className="hover:text-white transition">Products</Link>
            <Link href="/investors" className="hover:text-white transition">Investors</Link>
            <Link href="/careers" className="hover:text-white transition">Careers</Link>
            <Link href="/contact" className="hover:text-white transition">Contact</Link>
          </div>
          <div className="text-sm">
            © 2025 Wynaxa. All rights reserved. | Privacy Policy | Terms of Service
          </div>
        </div>
      </footer>
    </div>
  );
}
