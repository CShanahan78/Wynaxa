import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

export default function Careers() {
  const openRoles = [
    {
      title: "Senior Full Stack Engineer",
      department: "Engineering",
      location: "Remote (EU/UK)",
      type: "Full-time",
      color: "purple"
    },
    {
      title: "Community Growth Manager",
      department: "Community",
      location: "Bristol / Remote",
      type: "Full-time",
      color: "emerald"
    },
    {
      title: "Product Designer",
      department: "Product",
      location: "Remote (EU/UK)",
      type: "Full-time",
      color: "blue"
    },
    {
      title: "Partnerships Director",
      department: "Business Development",
      location: "Ireland / Remote",
      type: "Full-time",
      color: "orange"
    },
    {
      title: "DevOps Engineer",
      department: "Engineering",
      location: "Remote (EU/UK)",
      type: "Full-time",
      color: "purple"
    },
    {
      title: "Marketing Lead",
      department: "Marketing",
      location: "Remote (EU/UK)",
      type: "Full-time",
      color: "green"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-slate-900">Wynaxa</Link>

          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-slate-600 hover:text-slate-900 transition">About</Link>
            <Link href="/ecosystem" className="text-slate-600 hover:text-slate-900 transition">Ecosystem</Link>
            <Link href="/investors" className="text-slate-600 hover:text-slate-900 transition">Investors</Link>
            <Link href="/partners" className="text-slate-600 hover:text-slate-900 transition">Partners</Link>
            <Link href="/careers" className="text-slate-900 font-medium">Careers</Link>
            <Link href="/contact" className="text-slate-600 hover:text-slate-900 transition">Contact</Link>
          </div>

          <Button className="bg-emerald-600 hover:bg-emerald-700">
            View Open Roles
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-24 px-6 bg-gradient-to-br from-slate-50 to-white">
        <div className="max-w-4xl mx-auto text-center">
          <Badge className="mb-6 bg-emerald-100 text-emerald-800 hover:bg-emerald-200">
            We're Hiring!
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6">
            Build the Future with Wynaxa
          </h1>
          <p className="text-xl text-slate-600 mb-8">
            Join a team that's transforming local economies through technology.
            Work on products that create real, measurable impact in communities worldwide.
          </p>
          <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700">
            See Open Positions →
          </Button>
        </div>
      </section>

      {/* Why Wynaxa */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-16">
            Why Join Wynaxa?
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🚀</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Mission-Driven</h3>
              <p className="text-slate-600">
                Work on technology that creates positive social impact every day
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🌍</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Remote First</h3>
              <p className="text-slate-600">
                Work from anywhere in the EU/UK with flexible hours
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">📈</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Growth Opportunities</h3>
              <p className="text-slate-600">
                Fast-growing startup with room to learn and advance
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">💡</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Innovation</h3>
              <p className="text-slate-600">
                Solve complex problems with cutting-edge technology
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Open Positions */}
      <section className="py-24 px-6 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-4">
            Open Positions
          </h2>
          <p className="text-center text-slate-600 mb-12 text-lg">
            We're actively hiring across multiple departments. Join us in building the future.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {openRoles.map((role, index) => (
              <Card key={index} className="hover-lift cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">{role.title}</h3>
                      <p className="text-slate-600">{role.department}</p>
                    </div>
                    <Badge variant="secondary" className="bg-emerald-100 text-emerald-800">
                      {role.type}
                    </Badge>
                  </div>

                  <div className="flex items-center gap-4 mb-4 text-sm text-slate-500">
                    <span>📍 {role.location}</span>
                  </div>

                  <Button className={`w-full bg-${role.color}-600 hover:bg-${role.color}-700`}>
                    View Details & Apply →
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-16">
            Benefits & Perks
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">💰</span>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Competitive Salary</h3>
                <p className="text-slate-600">Market-leading compensation packages</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">📈</span>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Equity Options</h3>
                <p className="text-slate-600">Share in Wynaxa's success</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">🏥</span>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Health & Wellness</h3>
                <p className="text-slate-600">Comprehensive health coverage</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">🏝️</span>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Generous PTO</h3>
                <p className="text-slate-600">25 days annual leave + bank holidays</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">💻</span>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Equipment Budget</h3>
                <p className="text-slate-600">Latest tech and home office setup</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-2xl">📚</span>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Learning & Development</h3>
                <p className="text-slate-600">Conferences, courses, and training</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-24 px-6 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16">
            Our Values
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            <div className="text-center">
              <div className="text-4xl mb-4">✨</div>
              <h3 className="font-bold mb-2">Inspired</h3>
              <p className="text-slate-300 text-sm">Push boundaries</p>
            </div>

            <div className="text-center">
              <div className="text-4xl mb-4">🤝</div>
              <h3 className="font-bold mb-2">Trusted</h3>
              <p className="text-slate-300 text-sm">Act with integrity</p>
            </div>

            <div className="text-center">
              <div className="text-4xl mb-4">🚀</div>
              <h3 className="font-bold mb-2">Futuristic</h3>
              <p className="text-slate-300 text-sm">Build tomorrow</p>
            </div>

            <div className="text-center">
              <div className="text-4xl mb-4">💫</div>
              <h3 className="font-bold mb-2">Hopeful</h3>
              <p className="text-slate-300 text-sm">Create change</p>
            </div>

            <div className="text-center">
              <div className="text-4xl mb-4">👥</div>
              <h3 className="font-bold mb-2">Community-Led</h3>
              <p className="text-slate-300 text-sm">Listen first</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-slate-900 mb-6">
            Don't See Your Role?
          </h2>
          <p className="text-xl text-slate-600 mb-8">
            We're always looking for talented people who share our vision.
            Send us your CV and let's start a conversation.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700">
              Send Speculative Application
            </Button>
            <Button size="lg" variant="outline">
              Contact HR Team
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 bg-slate-950 text-slate-400">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex flex-wrap justify-center gap-6 mb-6">
            <Link href="/about" className="hover:text-white transition">About</Link>
            <Link href="/ecosystem" className="hover:text-white transition">Ecosystem</Link>
            <Link href="/investors" className="hover:text-white transition">Investors</Link>
            <Link href="/partners" className="hover:text-white transition">Partners</Link>
            <Link href="/careers" className="hover:text-white transition">Careers</Link>
            <Link href="/contact" className="hover:text-white transition">Contact</Link>
          </div>
          <div className="text-sm">
            © 2025 Wynaxa. All rights reserved. | Privacy Policy | Terms of Service
          </div>
        </div>
      </footer>
    </div>
  );
}
