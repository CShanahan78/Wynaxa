"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { useState } from "react";

export default function Products() {
  const [showOneDemo, setShowOneDemo] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-slate-900">Wynaxa</Link>

          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-slate-600 hover:text-slate-900 transition">About</Link>
            <Link href="/ecosystem" className="text-slate-600 hover:text-slate-900 transition">Ecosystem</Link>
            <Link href="/products" className="text-slate-900 font-medium">Products</Link>
            <Link href="/investors" className="text-slate-600 hover:text-slate-900 transition">Investors</Link>
            <Link href="/careers" className="text-slate-600 hover:text-slate-900 transition">Careers</Link>
            <Link href="/contact" className="text-slate-600 hover:text-slate-900 transition">Contact</Link>
          </div>

          <Link href="/investor-access">
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              Investor Access
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="py-24 px-6 bg-gradient-to-br from-slate-50 to-white">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6">
            Our Product Ecosystem
          </h1>
          <p className="text-xl text-slate-600">
            Four powerful products working together to transform local economies
          </p>
        </div>
      </section>

      {/* Quick Navigation */}
      <section className="py-12 px-6 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-wrap justify-center gap-4">
            <Button variant="outline" onClick={() => document.getElementById('pay')?.scrollIntoView({ behavior: 'smooth' })}>
              💳 Wynaxa Pay
            </Button>
            <Button variant="outline" onClick={() => document.getElementById('one')?.scrollIntoView({ behavior: 'smooth' })}>
              🏪 Wynaxa One
            </Button>
            <Button variant="outline" onClick={() => document.getElementById('eco')?.scrollIntoView({ behavior: 'smooth' })}>
              🌱 Wynaxa Eco
            </Button>
            <Button variant="outline" onClick={() => document.getElementById('foundry')?.scrollIntoView({ behavior: 'smooth' })}>
              🔬 Wynaxa Foundry
            </Button>
          </div>
        </div>
      </section>

      {/* Wynaxa Pay - MVP Screenshots */}
      <section id="pay" className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <div className="w-20 h-20 bg-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6">
              <span className="text-5xl">💳</span>
            </div>
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Wynaxa Pay</h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Smart local payments platform that keeps fees transparent and reinvests in your community
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">Key Features</h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-purple-600">✓</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900">Transparent Fee Structure</h4>
                    <p className="text-slate-600">Only 1.5% transaction fee - lower than traditional processors</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-purple-600">✓</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900">Local Reinvestment</h4>
                    <p className="text-slate-600">Portion of fees go directly back into local community projects</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-purple-600">✓</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900">Instant Settlement</h4>
                    <p className="text-slate-600">Get paid in 24 hours, not 3-5 business days</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-purple-600">✓</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900">Unified Dashboard</h4>
                    <p className="text-slate-600">Track sales, customers, and community impact in real-time</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">MVP Screenshots</h3>
              <div className="space-y-4">
                <Card className="overflow-hidden hover-lift">
                  <div className="bg-gradient-to-br from-purple-100 to-purple-200 p-8 aspect-video flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-6xl mb-4">💳</div>
                      <p className="text-slate-700 font-semibold">Payment Dashboard</p>
                      <p className="text-sm text-slate-600">Real-time transaction monitoring</p>
                    </div>
                  </div>
                </Card>

                <Card className="overflow-hidden hover-lift">
                  <div className="bg-gradient-to-br from-blue-100 to-blue-200 p-8 aspect-video flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-6xl mb-4">📊</div>
                      <p className="text-slate-700 font-semibold">Analytics View</p>
                      <p className="text-sm text-slate-600">Sales insights & community impact</p>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </div>

          <div className="text-center">
            <Badge className="mb-4 bg-purple-100 text-purple-800">Coming Soon - Beta Q2 2025</Badge>
            <br />
            <Button className="bg-purple-600 hover:bg-purple-700">
              Join Waitlist →
            </Button>
          </div>
        </div>
      </section>

      {/* Wynaxa One - Demo Access */}
      <section id="one" className="py-24 px-6 bg-gradient-to-br from-blue-50 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <div className="w-20 h-20 bg-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6">
              <span className="text-5xl">🏪</span>
            </div>
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Wynaxa One</h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Your unified marketplace for bookings, experiences, and local commerce - all in one platform
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">📅</div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Bookings & Reservations</h3>
                <p className="text-slate-600 mb-4">
                  Accept bookings for restaurants, hotels, and experiences with integrated calendar
                </p>
                <Badge variant="secondary">Live Now</Badge>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">🛒</div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">E-Commerce</h3>
                <p className="text-slate-600 mb-4">
                  Sell products online with built-in inventory management and delivery options
                </p>
                <Badge variant="secondary">Live Now</Badge>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">🚚</div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Delivery & Click-Collect</h3>
                <p className="text-slate-600 mb-4">
                  Offer delivery and collection services with route optimization
                </p>
                <Badge variant="secondary">Live Now</Badge>
              </CardContent>
            </Card>
          </div>

          {/* Demo Access Section */}
          {!showOneDemo ? (
            <div className="bg-white rounded-2xl p-12 shadow-xl max-w-3xl mx-auto text-center">
              <h3 className="text-3xl font-bold text-slate-900 mb-4">Try Wynaxa One Free</h3>
              <p className="text-lg text-slate-600 mb-8">
                Get 30 days free access to explore all features. No credit card required.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <Card className="text-left">
                  <CardContent className="p-6">
                    <h4 className="font-bold text-slate-900 mb-2">Free Plan</h4>
                    <div className="text-3xl font-bold text-slate-900 mb-4">£0<span className="text-sm font-normal text-slate-600">/month</span></div>
                    <ul className="space-y-2 text-sm text-slate-600">
                      <li>✓ Up to 50 bookings/month</li>
                      <li>✓ Basic e-commerce</li>
                      <li>✓ Email support</li>
                      <li>✓ Community features</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card className="text-left border-2 border-blue-600">
                  <CardContent className="p-6">
                    <Badge className="mb-2 bg-blue-600">Most Popular</Badge>
                    <h4 className="font-bold text-slate-900 mb-2">Pro Plan</h4>
                    <div className="text-3xl font-bold text-slate-900 mb-4">£29<span className="text-sm font-normal text-slate-600">/month</span></div>
                    <ul className="space-y-2 text-sm text-slate-600">
                      <li>✓ Unlimited bookings</li>
                      <li>✓ Advanced e-commerce</li>
                      <li>✓ Priority support</li>
                      <li>✓ Analytics dashboard</li>
                      <li>✓ Custom branding</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>

              <Button
                size="lg"
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => setShowOneDemo(true)}
              >
                Start Free Trial →
              </Button>
            </div>
          ) : (
            <div className="bg-white rounded-2xl p-12 shadow-xl max-w-2xl mx-auto">
              <h3 className="text-2xl font-bold text-slate-900 mb-6 text-center">Create Your Wynaxa One Account</h3>
              <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); alert('Demo signup! In production, this would create your account.'); }}>
                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-2">Business Name</label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Your Business Name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-2">Email</label>
                  <input
                    type="email"
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="you@business.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-2">Password</label>
                  <input
                    type="password"
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Create a password"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-2">Choose Plan</label>
                  <select className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option>Free - £0/month</option>
                    <option>Pro - £29/month (30 day free trial)</option>
                  </select>
                </div>
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                  Start Your Free Trial
                </Button>
                <p className="text-xs text-slate-500 text-center">
                  No credit card required for free trial. Cancel anytime.
                </p>
              </form>
            </div>
          )}
        </div>
      </section>

      {/* Wynaxa Eco - Order Online */}
      <section id="eco" className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <div className="w-20 h-20 bg-green-600 rounded-3xl flex items-center justify-center mx-auto mb-6">
              <span className="text-5xl">🌱</span>
            </div>
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Wynaxa Eco</h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Circular economy marketplace rewarding sustainable choices and supporting local green businesses
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-12">
            <div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">Shop Sustainably</h3>
              <div className="space-y-4 mb-8">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-green-600">🌿</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900">Local Organic Products</h4>
                    <p className="text-slate-600">Farm-fresh produce, artisan goods, and eco-friendly products</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-green-600">♻️</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900">Carbon-Neutral Delivery</h4>
                    <p className="text-slate-600">EAV electric bikes and smart collection points</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-green-600">💚</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900">Earn Green Rewards</h4>
                    <p className="text-slate-600">Get points for sustainable purchases to spend locally</p>
                  </div>
                </div>
              </div>

              <a href="https://eco.wynaxa.com" target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-green-600 hover:bg-green-700">
                  Start Shopping on Wynaxa Eco →
                </Button>
              </a>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Card className="overflow-hidden hover-lift">
                <div className="bg-gradient-to-br from-green-100 to-green-200 p-6 aspect-square flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-5xl mb-2">🥬</div>
                    <p className="text-sm font-semibold text-slate-700">Fresh Produce</p>
                  </div>
                </div>
              </Card>

              <Card className="overflow-hidden hover-lift">
                <div className="bg-gradient-to-br from-blue-100 to-blue-200 p-6 aspect-square flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-5xl mb-2">🏺</div>
                    <p className="text-sm font-semibold text-slate-700">Artisan Goods</p>
                  </div>
                </div>
              </Card>

              <Card className="overflow-hidden hover-lift">
                <div className="bg-gradient-to-br from-yellow-100 to-yellow-200 p-6 aspect-square flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-5xl mb-2">🌾</div>
                    <p className="text-sm font-semibold text-slate-700">Zero Waste</p>
                  </div>
                </div>
              </Card>

              <Card className="overflow-hidden hover-lift">
                <div className="bg-gradient-to-br from-purple-100 to-purple-200 p-6 aspect-square flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-5xl mb-2">🌸</div>
                    <p className="text-sm font-semibold text-slate-700">Natural Beauty</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>

          <div className="bg-green-50 rounded-2xl p-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              <div>
                <div className="text-3xl font-bold text-green-600 mb-2">18,500t</div>
                <div className="text-sm text-slate-600">Carbon Saved</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-600 mb-2">450+</div>
                <div className="text-sm text-slate-600">Green Vendors</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-600 mb-2">95%</div>
                <div className="text-sm text-slate-600">Local Sourcing</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-600 mb-2">£2.1M</div>
                <div className="text-sm text-slate-600">Green Economy</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Wynaxa Foundry - Innovation Lab */}
      <section id="foundry" className="py-24 px-6 bg-gradient-to-br from-orange-50 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <div className="w-20 h-20 bg-orange-600 rounded-3xl flex items-center justify-center mx-auto mb-6">
              <span className="text-5xl">🔬</span>
            </div>
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Wynaxa Foundry</h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Our innovation lab incubating technology for good - from concept to community rollout
            </p>
          </div>

          {/* Office Visualization */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold text-slate-900 mb-6 text-center">Inside Our Innovation Lab</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="overflow-hidden hover-lift">
                <div className="bg-gradient-to-br from-orange-100 to-red-100 p-12 aspect-video flex flex-col items-center justify-center">
                  <div className="text-7xl mb-4">💡</div>
                  <p className="text-slate-700 font-semibold text-lg">Innovation Studio</p>
                  <p className="text-sm text-slate-600">Collaborative workspace for ideation</p>
                </div>
              </Card>

              <Card className="overflow-hidden hover-lift">
                <div className="bg-gradient-to-br from-blue-100 to-purple-100 p-12 aspect-video flex flex-col items-center justify-center">
                  <div className="text-7xl mb-4">🖥️</div>
                  <p className="text-slate-700 font-semibold text-lg">Development Lab</p>
                  <p className="text-sm text-slate-600">Rapid prototyping & testing environment</p>
                </div>
              </Card>

              <Card className="overflow-hidden hover-lift">
                <div className="bg-gradient-to-br from-green-100 to-teal-100 p-12 aspect-video flex flex-col items-center justify-center">
                  <div className="text-7xl mb-4">🤝</div>
                  <p className="text-slate-700 font-semibold text-lg">Community Hub</p>
                  <p className="text-sm text-slate-600">Partner collaboration spaces</p>
                </div>
              </Card>

              <Card className="overflow-hidden hover-lift">
                <div className="bg-gradient-to-br from-yellow-100 to-orange-100 p-12 aspect-video flex flex-col items-center justify-center">
                  <div className="text-7xl mb-4">📊</div>
                  <p className="text-slate-700 font-semibold text-lg">Impact Analytics Room</p>
                  <p className="text-sm text-slate-600">Measuring social & economic outcomes</p>
                </div>
              </Card>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
            <div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">What We're Building</h3>
              <div className="space-y-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <Badge className="bg-orange-600">In Development</Badge>
                      <h4 className="font-semibold text-slate-900">AI-Powered Local Matching</h4>
                    </div>
                    <p className="text-sm text-slate-600">
                      Connecting consumers with the perfect local businesses using machine learning
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <Badge className="bg-blue-600">Testing</Badge>
                      <h4 className="font-semibold text-slate-900">Blockchain Community Voting</h4>
                    </div>
                    <p className="text-sm text-slate-600">
                      Transparent, secure voting system for local investment decisions
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <Badge className="bg-green-600">Research</Badge>
                      <h4 className="font-semibold text-slate-900">Impact Prediction Engine</h4>
                    </div>
                    <p className="text-sm text-slate-600">
                      Forecasting social and economic impact of community investments
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">Partner With Us</h3>
              <p className="text-slate-600 mb-6">
                We collaborate with universities, tech companies, and local councils to develop
                solutions that create lasting positive impact.
              </p>

              <div className="bg-orange-50 rounded-xl p-6 mb-6">
                <h4 className="font-semibold text-slate-900 mb-3">Current Partners</h4>
                <div className="space-y-2 text-sm text-slate-600">
                  <div>🎓 University of Bristol - AI Research</div>
                  <div>🏛️ Bristol City Council - Smart City Initiative</div>
                  <div>💼 Tech Nation - Startup Support</div>
                  <div>🌍 ClimateAction.tech - Sustainability</div>
                </div>
              </div>

              <Button className="bg-orange-600 hover:bg-orange-700 w-full">
                Collaborate with Foundry →
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 bg-slate-950 text-slate-400">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex flex-wrap justify-center gap-6 mb-6">
            <Link href="/about" className="hover:text-white transition">About</Link>
            <Link href="/ecosystem" className="hover:text-white transition">Ecosystem</Link>
            <Link href="/products" className="hover:text-white transition">Products</Link>
            <Link href="/investors" className="hover:text-white transition">Investors</Link>
            <Link href="/careers" className="hover:text-white transition">Careers</Link>
            <Link href="/contact" className="hover:text-white transition">Contact</Link>
          </div>
          <div className="text-sm">
            © 2025 Wynaxa. All rights reserved. | Privacy Policy | Terms of Service
          </div>
        </div>
      </footer>
    </div>
  );
}
