"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";
import { useState } from "react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    purpose: "general",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Thank you for your message! We'll be in touch shortly.");
    setFormData({ name: "", email: "", company: "", purpose: "general", message: "" });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-slate-900">Wynaxa</Link>

          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-slate-600 hover:text-slate-900 transition">About</Link>
            <Link href="/ecosystem" className="text-slate-600 hover:text-slate-900 transition">Ecosystem</Link>
            <Link href="/investors" className="text-slate-600 hover:text-slate-900 transition">Investors</Link>
            <Link href="/partners" className="text-slate-600 hover:text-slate-900 transition">Partners</Link>
            <Link href="/careers" className="text-slate-600 hover:text-slate-900 transition">Careers</Link>
            <Link href="/contact" className="text-slate-900 font-medium">Contact</Link>
          </div>

          <Link href="/investor-access">
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              Investor Access
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="py-24 px-6 bg-gradient-to-br from-slate-50 to-white">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6">
            Get in Touch
          </h1>
          <p className="text-xl text-slate-600">
            We'd love to hear from you. Reach out to discuss partnerships, investments, or general inquiries.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-8">Send Us a Message</h2>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="John Smith"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="john@company.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-2">
                    Company / Organization
                  </label>
                  <input
                    type="text"
                    value={formData.company}
                    onChange={(e) => setFormData({...formData, company: e.target.value})}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Your Company Ltd"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-2">
                    Purpose of Inquiry *
                  </label>
                  <select
                    required
                    value={formData.purpose}
                    onChange={(e) => setFormData({...formData, purpose: e.target.value})}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="general">General Inquiry</option>
                    <option value="investor">Investment Opportunity</option>
                    <option value="partner">Partnership</option>
                    <option value="media">Media & Press</option>
                    <option value="support">Technical Support</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-2">
                    Message *
                  </label>
                  <textarea
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    rows={6}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Tell us about your inquiry..."
                  />
                </div>

                <Button type="submit" size="lg" className="w-full bg-emerald-600 hover:bg-emerald-700">
                  Send Message
                </Button>
              </form>
            </div>

            {/* Contact Information */}
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-8">Contact Information</h2>

              <div className="space-y-8 mb-12">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <span className="text-2xl">📧</span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900 mb-1">Email</h3>
                        <p className="text-slate-600">General: <a href="mailto:hello@wynaxa.com" className="text-emerald-600 hover:underline">hello@wynaxa.com</a></p>
                        <p className="text-slate-600">Investors: <a href="mailto:investors@wynaxa.com" className="text-emerald-600 hover:underline">investors@wynaxa.com</a></p>
                        <p className="text-slate-600">Support: <a href="mailto:support@wynaxa.com" className="text-emerald-600 hover:underline">support@wynaxa.com</a></p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <span className="text-2xl">🏢</span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900 mb-1">Headquarters</h3>
                        <p className="text-slate-600">
                          Wynaxa Ltd<br />
                          Dublin, Ireland
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <span className="text-2xl">🇮🇳</span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900 mb-1">India Office</h3>
                        <p className="text-slate-600">
                          Wynaxa India<br />
                          Surat, Gujarat, India
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <span className="text-2xl">🌐</span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900 mb-1">Social Media</h3>
                        <div className="space-y-1">
                          <p className="text-slate-600">LinkedIn: <a href="#" className="text-emerald-600 hover:underline">@wynaxa</a></p>
                          <p className="text-slate-600">Instagram: <a href="#" className="text-emerald-600 hover:underline">@wynaxa</a></p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Newsletter Signup */}
              <div className="bg-gradient-to-br from-emerald-50 to-blue-50 rounded-2xl p-8">
                <h3 className="text-2xl font-bold text-slate-900 mb-4">Stay Updated</h3>
                <p className="text-slate-600 mb-6">
                  Subscribe to our newsletter for updates on product launches, partnerships, and impact stories.
                </p>
                <div className="flex gap-2">
                  <input
                    type="email"
                    placeholder="your@email.com"
                    className="flex-1 px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <Button className="bg-emerald-600 hover:bg-emerald-700">
                    Subscribe
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 bg-slate-950 text-slate-400">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex flex-wrap justify-center gap-6 mb-6">
            <Link href="/about" className="hover:text-white transition">About</Link>
            <Link href="/ecosystem" className="hover:text-white transition">Ecosystem</Link>
            <Link href="/investors" className="hover:text-white transition">Investors</Link>
            <Link href="/partners" className="hover:text-white transition">Partners</Link>
            <Link href="/careers" className="hover:text-white transition">Careers</Link>
            <Link href="/contact" className="hover:text-white transition">Contact</Link>
          </div>
          <div className="text-sm">
            © 2025 Wynaxa. All rights reserved. | Privacy Policy | Terms of Service
          </div>
        </div>
      </footer>
    </div>
  );
}
