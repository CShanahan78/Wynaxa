"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { useState } from "react";

export default function InvestorAccess() {
  const [hasAccess, setHasAccess] = useState(false);
  const [activeModule, setActiveModule] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    linkedIn: ""
  });

  const handleAccessRequest = (e: React.FormEvent) => {
    e.preventDefault();
    // In production, you'd send this to your backend/CRM
    console.log("Investor access requested:", formData);
    setHasAccess(true);
    // Scroll to top of deck
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const ecosystemModules = [
    { name: "Bookings", icon: "📅", description: "Simplifying local hospitality" },
    { name: "POS & Payments", icon: "💳", description: "Reducing transaction fees, reinvesting locally" },
    { name: "E-commerce", icon: "🛒", description: "Unified online storefronts" },
    { name: "Click & Collect", icon: "📦", description: "Smart delivery and pickup" },
    { name: "QR Ordering", icon: "📱", description: "Contactless table service" },
    { name: "Events", icon: "🎉", description: "Community experiences" },
    { name: "Marketing", icon: "📊", description: "Built-in CRM and campaigns" },
    { name: "Wallet", icon: "💰", description: "Rewards and loyalty" },
  ];

  // If user hasn't requested access yet, show gated entry
  if (!hasAccess) {
    return (
      <div className="min-h-screen bg-[#0D1B2A] text-white">
        {/* Minimal Nav */}
        <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0D1B2A]/95 backdrop-blur-md border-b border-white/10">
          <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-[#00E6B8]">Wynaxa</Link>
            <Badge className="bg-[#00E6B8] text-[#0D1B2A] hover:bg-[#00E6B8]/90">
              Investor Access
            </Badge>
          </div>
        </nav>

        {/* Gated Hero */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20 px-6">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-[#00E6B8] rounded-full animate-pulse"></div>
            <div className="absolute top-1/3 right-1/4 w-2 h-2 bg-[#00E6B8] rounded-full animate-pulse delay-100"></div>
            <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-[#00E6B8] rounded-full animate-pulse delay-200"></div>
            <div className="absolute bottom-1/4 right-1/3 w-2 h-2 bg-[#00E6B8] rounded-full animate-pulse delay-300"></div>
          </div>

          <div className="relative z-10 max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-5xl md:text-6xl font-bold mb-6">
                The Future,<br />
                <span className="text-[#00E6B8]">Connected Locally.</span>
              </h1>
              <p className="text-xl text-slate-300 mb-8">
                Exclusive investment opportunity in the platform transforming local economies
              </p>
            </div>

            {/* Teaser Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
              <div className="text-center">
                <div className="text-3xl font-bold text-[#00E6B8] mb-2">£500K</div>
                <div className="text-sm text-slate-400">Raising</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#FF6B6B] mb-2">15%</div>
                <div className="text-sm text-slate-400">Equity</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#A78BFA] mb-2">£2.83M</div>
                <div className="text-sm text-slate-400">Pre-Money</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#10B981] mb-2">2,847</div>
                <div className="text-sm text-slate-400">Businesses</div>
              </div>
            </div>

            {/* Access Request Form */}
            <Card className="bg-[#1a2838] border-[#00E6B8]/30 max-w-2xl mx-auto">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold mb-2">Request Access to Full Investor Deck</h2>
                  <p className="text-slate-400">
                    Enter your details to view our complete investment opportunity presentation
                  </p>
                </div>

                <form onSubmit={handleAccessRequest} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="w-full px-4 py-3 bg-[#0D1B2A] border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00E6B8] text-white"
                      placeholder="John Smith"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="w-full px-4 py-3 bg-[#0D1B2A] border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00E6B8] text-white"
                      placeholder="john@company.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Company / Fund Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.company}
                      onChange={(e) => setFormData({...formData, company: e.target.value})}
                      className="w-full px-4 py-3 bg-[#0D1B2A] border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00E6B8] text-white"
                      placeholder="Investment Partners Ltd"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">LinkedIn Profile (Optional)</label>
                    <input
                      type="url"
                      value={formData.linkedIn}
                      onChange={(e) => setFormData({...formData, linkedIn: e.target.value})}
                      className="w-full px-4 py-3 bg-[#0D1B2A] border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00E6B8] text-white"
                      placeholder="https://linkedin.com/in/yourprofile"
                    />
                  </div>

                  <div className="pt-4">
                    <Button type="submit" size="lg" className="w-full bg-[#00E6B8] hover:bg-[#00E6B8]/90 text-[#0D1B2A] font-semibold">
                      Access Full Investor Deck →
                    </Button>
                  </div>

                  <p className="text-xs text-slate-400 text-center">
                    By submitting, you agree to our confidentiality terms. This information is for qualified investors only.
                  </p>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 px-6 bg-[#0D1B2A] border-t border-white/10">
          <div className="max-w-7xl mx-auto text-center text-slate-400 text-sm">
            <p>© 2025 Wynaxa. Confidential Investment Materials. All rights reserved.</p>
            <p className="mt-2">
              <Link href="/" className="hover:text-[#00E6B8] transition">Back to Main Site</Link>
              {" "} | {" "}
              <a href="mailto:investors@wynaxa.com" className="hover:text-[#00E6B8] transition">investors@wynaxa.com</a>
            </p>
          </div>
        </footer>
      </div>
    );
  }

  // Full deck view (after access granted)
  return (
    <div className="min-h-screen bg-[#0D1B2A] text-white">
      {/* Minimal Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0D1B2A]/95 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-[#00E6B8]">Wynaxa</Link>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-400">Welcome, {formData.name.split(' ')[0]}</span>
            <Badge className="bg-[#00E6B8] text-[#0D1B2A] hover:bg-[#00E6B8]/90">
              Investor Access
            </Badge>
          </div>
        </div>
      </nav>

      {/* 1. Hero / Gate Page */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
        {/* Animated background network */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-[#00E6B8] rounded-full animate-pulse"></div>
          <div className="absolute top-1/3 right-1/4 w-2 h-2 bg-[#00E6B8] rounded-full animate-pulse delay-100"></div>
          <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-[#00E6B8] rounded-full animate-pulse delay-200"></div>
          <div className="absolute bottom-1/4 right-1/3 w-2 h-2 bg-[#00E6B8] rounded-full animate-pulse delay-300"></div>
        </div>

        <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
          <Badge className="mb-6 bg-emerald-600 text-white">
            ✓ Access Granted
          </Badge>
          <div className="mb-8">
            <h1 className="text-6xl md:text-7xl font-bold mb-4">
              The Future,<br />
              <span className="text-[#00E6B8]">Connected Locally.</span>
            </h1>
            <p className="text-xl text-slate-300">
              Wynaxa Investor Deck • Confidential
            </p>
          </div>

          <Button
            size="lg"
            className="bg-[#00E6B8] hover:bg-[#00E6B8]/90 text-[#0D1B2A] font-semibold"
            onClick={() => document.getElementById('overview')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Explore Investment Opportunity →
          </Button>

          <p className="mt-6 text-sm text-slate-400">
            Scroll to explore our vision, traction, and £500K investment opportunity
          </p>
        </div>
      </section>

      {/* 2. Overview / The Opportunity */}
      <section id="overview" className="py-24 px-6 bg-gradient-to-b from-[#0D1B2A] to-[#1a2838]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Local economies are the world's<br />
              most <span className="text-[#00E6B8]">untapped digital opportunity</span>
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Despite £120B spent locally every year, small businesses still rely on outdated,
              disconnected tools — losing margin, data, and customers.
            </p>
          </div>

          {/* Problem → Solution Visual */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="bg-red-900/20 border border-red-500/30 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-red-400 mb-6">Old World</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-slate-300">
                  <span className="text-red-400">×</span> Fragmented apps
                </div>
                <div className="flex items-center gap-3 text-slate-300">
                  <span className="text-red-400">×</span> High transaction fees
                </div>
                <div className="flex items-center gap-3 text-slate-300">
                  <span className="text-red-400">×</span> Lost customer data
                </div>
                <div className="flex items-center gap-3 text-slate-300">
                  <span className="text-red-400">×</span> No local reinvestment
                </div>
              </div>
            </div>

            <div className="bg-[#00E6B8]/10 border border-[#00E6B8]/30 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-[#00E6B8] mb-6">Wynaxa World</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-slate-300">
                  <span className="text-[#00E6B8]">✓</span> Single ecosystem
                </div>
                <div className="flex items-center gap-3 text-slate-300">
                  <span className="text-[#00E6B8]">✓</span> Transparent, low fees
                </div>
                <div className="flex items-center gap-3 text-slate-300">
                  <span className="text-[#00E6B8]">✓</span> Unified customer insights
                </div>
                <div className="flex items-center gap-3 text-slate-300">
                  <span className="text-[#00E6B8]">✓</span> Community reinvestment
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Solution / Ecosystem Map */}
      <section className="py-24 px-6 bg-[#0D1B2A]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              An <span className="text-[#00E6B8]">all-in-one platform</span><br />
              connecting commerce, fintech, and community
            </h2>
          </div>

          {/* Interactive Module Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {ecosystemModules.map((module, index) => (
              <Card
                key={index}
                className="bg-[#1a2838] border-slate-700 hover:border-[#00E6B8] hover:bg-[#1a2838]/80 cursor-pointer transition-all hover-lift"
                onMouseEnter={() => setActiveModule(module.name)}
                onMouseLeave={() => setActiveModule(null)}
              >
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-3">{module.icon}</div>
                  <h3 className="font-semibold text-white">{module.name}</h3>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Active Module Description */}
          <div className="min-h-[80px] flex items-center justify-center">
            {activeModule && (
              <div className="text-center animate-fade-in-up">
                <p className="text-lg text-[#00E6B8]">
                  {ecosystemModules.find(m => m.name === activeModule)?.description}
                </p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* 4. Market & Momentum */}
      <section className="py-24 px-6 bg-gradient-to-b from-[#0D1B2A] to-[#1a2838]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              We're launching in <span className="text-[#00E6B8]">Bristol</span> —<br />
              the blueprint for every local economy
            </h2>
            <p className="text-xl text-slate-300">
              Supported by regional councils and partnerships, our go-to-market strategy<br />
              starts in the UK, scaling to Ireland and India.
            </p>
          </div>

          {/* Rollout Map */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <Card className="bg-[#00E6B8]/10 border-[#00E6B8]">
              <CardContent className="p-8 text-center">
                <div className="text-5xl mb-4">🇬🇧</div>
                <h3 className="text-2xl font-bold text-[#00E6B8] mb-2">Bristol</h3>
                <p className="text-slate-300">Launch city • Now live</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="p-8 text-center">
                <div className="text-5xl mb-4">🇮🇪</div>
                <h3 className="text-2xl font-bold mb-2">Dublin</h3>
                <p className="text-slate-300">HQ expansion • Q2 2025</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="p-8 text-center">
                <div className="text-5xl mb-4">🌍</div>
                <h3 className="text-2xl font-bold mb-2">Global</h3>
                <p className="text-slate-300">Scale phase • 2026</p>
              </CardContent>
            </Card>
          </div>

          {/* Traction Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-[#00E6B8] mb-2">2,847</div>
              <div className="text-slate-400">Business Pipeline</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-[#FF6B6B] mb-2">156</div>
              <div className="text-slate-400">Communities</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-[#00E6B8] mb-2">£4.2M</div>
              <div className="text-slate-400">Local Impact</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-[#FF6B6B] mb-2">85%</div>
              <div className="text-slate-400">Retention Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Business Model & Impact */}
      <section className="py-24 px-6 bg-[#0D1B2A]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="text-[#00E6B8]">Profit</span> with <span className="text-[#FF6B6B]">Purpose</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Business Model */}
            <div>
              <h3 className="text-2xl font-bold mb-6 text-[#00E6B8]">Revenue Streams</h3>
              <div className="space-y-4">
                <div className="bg-[#1a2838] rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-semibold">SaaS Subscriptions</span>
                    <span className="text-[#00E6B8]">£0–£50/month</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div className="bg-[#00E6B8] h-2 rounded-full" style={{width: '40%'}}></div>
                  </div>
                </div>

                <div className="bg-[#1a2838] rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-semibold">Transaction Fees</span>
                    <span className="text-[#00E6B8]">1.5%</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div className="bg-[#00E6B8] h-2 rounded-full" style={{width: '35%'}}></div>
                  </div>
                </div>

                <div className="bg-[#1a2838] rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-semibold">Commission (Delivery/Booking)</span>
                    <span className="text-[#00E6B8]">10-15%</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div className="bg-[#00E6B8] h-2 rounded-full" style={{width: '20%'}}></div>
                  </div>
                </div>

                <div className="bg-[#1a2838] rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-semibold">Marketplace Ads</span>
                    <span className="text-[#00E6B8]">Variable</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div className="bg-[#00E6B8] h-2 rounded-full" style={{width: '5%'}}></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Impact */}
            <div>
              <h3 className="text-2xl font-bold mb-6 text-[#FF6B6B]">ESG Impact</h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#FF6B6B]/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">💰</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Local Reinvestment Fund</h4>
                    <p className="text-slate-300 text-sm">Portion of fees reinvested directly into small businesses and community initiatives</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#FF6B6B]/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">🌱</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Economic Inclusion</h4>
                    <p className="text-slate-300 text-sm">Digital access and opportunity for underserved local businesses</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#FF6B6B]/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">🚴</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Carbon-Neutral Delivery</h4>
                    <p className="text-slate-300 text-sm">EAV bikes and smart collection points reducing environmental impact</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Investment Opportunity */}
      <section className="py-24 px-6 bg-gradient-to-b from-[#1a2838] to-[#0D1B2A]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Invest in the <span className="text-[#00E6B8]">infrastructure</span><br />
              powering local economies
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
            <Card className="bg-[#00E6B8]/10 border-[#00E6B8]">
              <CardContent className="p-8 text-center">
                <h3 className="text-lg text-slate-400 mb-2">Raise Amount</h3>
                <div className="text-5xl font-bold text-[#00E6B8] mb-2">£500K</div>
                <p className="text-slate-300">for 15% equity</p>
              </CardContent>
            </Card>

            <Card className="bg-[#FF6B6B]/10 border-[#FF6B6B]">
              <CardContent className="p-8 text-center">
                <h3 className="text-lg text-slate-400 mb-2">Pre-Money Valuation</h3>
                <div className="text-5xl font-bold text-[#FF6B6B] mb-2">£2.83M</div>
                <p className="text-slate-300">Post: £3.33M</p>
              </CardContent>
            </Card>

            <Card className="bg-purple-500/10 border-purple-500">
              <CardContent className="p-8 text-center">
                <h3 className="text-lg text-slate-400 mb-2">Runway</h3>
                <div className="text-5xl font-bold text-purple-400 mb-2">18M</div>
                <p className="text-slate-300">months to profitability</p>
              </CardContent>
            </Card>
          </div>

          {/* Use of Funds */}
          <div className="bg-[#1a2838] rounded-2xl p-8 mb-8">
            <h3 className="text-2xl font-bold mb-6 text-center">Use of Funds</h3>
            <div className="space-y-4">
              {[
                { label: 'Marketing & Customer Acquisition', percent: 30, color: '#00E6B8' },
                { label: 'Technical Team Expansion', percent: 25, color: '#FF6B6B' },
                { label: 'Product Automation', percent: 20, color: '#A78BFA' },
                { label: 'Operations & Legal Setup', percent: 15, color: '#F59E0B' },
                { label: 'Contingency & Runway', percent: 10, color: '#10B981' },
              ].map((item, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{item.label}</span>
                    <span className="text-[#00E6B8]">{item.percent}%</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-3">
                    <div
                      className="h-3 rounded-full"
                      style={{width: `${item.percent}%`, backgroundColor: item.color}}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="text-center">
            <Button size="lg" className="bg-[#00E6B8] hover:bg-[#00E6B8]/90 text-[#0D1B2A] font-semibold mr-4">
              Request Full Investor Pack
            </Button>
            <Button size="lg" variant="outline" className="border-[#00E6B8] text-[#00E6B8] hover:bg-[#00E6B8]/10">
              Book a Meeting with CEO
            </Button>
          </div>
        </div>
      </section>

      {/* 7. Team & Contact CTA */}
      <section className="py-24 px-6 bg-[#0D1B2A]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Led by innovators who've<br />
              <span className="text-[#00E6B8]">built and scaled from the ground up</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <Card className="bg-[#1a2838] border-slate-700 hover-lift">
              <CardContent className="p-8 text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-[#00E6B8] to-[#0D9488] rounded-full mx-auto mb-4"></div>
                <h3 className="text-xl font-bold mb-1">Christian Shanahan</h3>
                <p className="text-[#00E6B8] font-medium mb-3">Founder & CEO</p>
                <p className="text-slate-300 text-sm italic">
                  "Building technology that serves communities, not corporations."
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1a2838] border-slate-700 hover-lift">
              <CardContent className="p-8 text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-[#FF6B6B] to-[#DC2626] rounded-full mx-auto mb-4"></div>
                <h3 className="text-xl font-bold mb-1">Mike Todd</h3>
                <p className="text-[#FF6B6B] font-medium mb-3">Chief Strategy Officer</p>
                <p className="text-slate-300 text-sm italic">
                  "Local economies deserve world-class technology."
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1a2838] border-slate-700 hover-lift">
              <CardContent className="p-8 text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-[#A78BFA] to-[#7C3AED] rounded-full mx-auto mb-4"></div>
                <h3 className="text-xl font-bold mb-1">Roshni Patel</h3>
                <p className="text-[#A78BFA] font-medium mb-3">Chief Technology Officer</p>
                <p className="text-slate-300 text-sm italic">
                  "Innovation grounded in real-world impact."
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Final CTA */}
          <div className="text-center bg-gradient-to-r from-[#00E6B8]/20 to-[#FF6B6B]/20 rounded-2xl p-12 border border-[#00E6B8]/30">
            <h3 className="text-3xl font-bold mb-4">
              Join us in building the future,<br />
              <span className="text-[#00E6B8]">connected locally</span>
            </h3>
            <p className="text-xl text-slate-300 mb-8">
              Schedule a call with our team to discuss the opportunity in detail
            </p>
            <Button size="lg" className="bg-[#00E6B8] hover:bg-[#00E6B8]/90 text-[#0D1B2A] font-semibold text-lg px-8">
              Request Investor Call →
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 bg-[#0D1B2A] border-t border-white/10">
        <div className="max-w-7xl mx-auto text-center text-slate-400 text-sm">
          <p>© 2025 Wynaxa. Confidential Investment Materials. All rights reserved.</p>
          <p className="mt-2">
            <Link href="/" className="hover:text-[#00E6B8] transition">Back to Main Site</Link>
            {" "} | {" "}
            <a href="mailto:investors@wynaxa.com" className="hover:text-[#00E6B8] transition">investors@wynaxa.com</a>
          </p>
        </div>
      </footer>
    </div>
  );
}
