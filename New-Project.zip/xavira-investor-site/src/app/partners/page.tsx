import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";

export default function Partners() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-slate-900">Wynaxa</Link>

          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-slate-600 hover:text-slate-900 transition">About</Link>
            <Link href="/ecosystem" className="text-slate-600 hover:text-slate-900 transition">Ecosystem</Link>
            <Link href="/investors" className="text-slate-600 hover:text-slate-900 transition">Investors</Link>
            <Link href="/partners" className="text-slate-900 font-medium">Partners</Link>
            <Link href="/careers" className="text-slate-600 hover:text-slate-900 transition">Careers</Link>
            <Link href="/contact" className="text-slate-600 hover:text-slate-900 transition">Contact</Link>
          </div>

          <Link href="/investor-access">
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              Investor Access
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="py-24 px-6 bg-gradient-to-br from-slate-50 to-white">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6">
            Partnerships that<br />Power Progress
          </h1>
          <p className="text-xl text-slate-600">
            Join councils, businesses, and communities building the future of local economies
          </p>
        </div>
      </section>

      {/* Partnership Types */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-16">
            Partnership Opportunities
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="hover-lift">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mb-6">
                  <span className="text-3xl">🏛️</span>
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4">Local Councils</h3>
                <p className="text-slate-600 mb-6">
                  Empower your local businesses with digital infrastructure that keeps economic value in your community.
                </p>
                <ul className="space-y-2 text-sm text-slate-600 mb-6">
                  <li>• Economic development support</li>
                  <li>• Job creation tracking</li>
                  <li>• Community engagement tools</li>
                </ul>
                <Button variant="outline" className="w-full">
                  Learn More →
                </Button>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
                  <span className="text-3xl">🏪</span>
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4">Business Networks</h3>
                <p className="text-slate-600 mb-6">
                  Provide your members with cutting-edge tools to compete with national chains while staying independent.
                </p>
                <ul className="space-y-2 text-sm text-slate-600 mb-6">
                  <li>• Member discount programs</li>
                  <li>• White-label solutions</li>
                  <li>• Collective bargaining power</li>
                </ul>
                <Button variant="outline" className="w-full">
                  Learn More →
                </Button>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                  <span className="text-3xl">🤝</span>
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4">Technology Partners</h3>
                <p className="text-slate-600 mb-6">
                  Integrate your solutions with our ecosystem to reach thousands of local businesses.
                </p>
                <ul className="space-y-2 text-sm text-slate-600 mb-6">
                  <li>• API access and documentation</li>
                  <li>• Co-marketing opportunities</li>
                  <li>• Revenue sharing models</li>
                </ul>
                <Button variant="outline" className="w-full">
                  Learn More →
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Partner Logos */}
      <section className="py-24 px-6 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-4">
            Trusted by Leading Organizations
          </h2>
          <p className="text-center text-slate-600 mb-12">
            Working with councils, fintechs, and local networks across the UK and Ireland
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
              <div key={i} className="bg-white rounded-lg p-8 flex items-center justify-center h-32">
                <div className="text-slate-400 font-semibold">Partner Logo {i}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Case Studies */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-slate-900 mb-16">
            Success Stories
          </h2>

          <div className="space-y-12">
            <Card className="overflow-hidden">
              <div className="grid grid-cols-1 lg:grid-cols-2">
                <div className="bg-gradient-to-br from-emerald-100 to-blue-100 p-12 flex items-center justify-center">
                  <div className="text-6xl">🏙️</div>
                </div>
                <CardContent className="p-12">
                  <h3 className="text-2xl font-bold text-slate-900 mb-4">
                    Bristol City Partnership
                  </h3>
                  <p className="text-slate-600 mb-6">
                    Working with Bristol City Council to empower over 500 local businesses
                    with integrated payment, booking, and delivery solutions.
                  </p>
                  <div className="grid grid-cols-3 gap-4 mb-6">
                    <div>
                      <div className="text-3xl font-bold text-emerald-600">500+</div>
                      <div className="text-sm text-slate-600">Businesses</div>
                    </div>
                    <div>
                      <div className="text-3xl font-bold text-blue-600">£2.1M</div>
                      <div className="text-sm text-slate-600">Local Impact</div>
                    </div>
                    <div>
                      <div className="text-3xl font-bold text-purple-600">92%</div>
                      <div className="text-sm text-slate-600">Satisfaction</div>
                    </div>
                  </div>
                  <Button>Read Full Case Study →</Button>
                </CardContent>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6 bg-slate-900 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">
            Collaborate with Wynaxa
          </h2>
          <p className="text-xl text-slate-300 mb-8">
            Let's build sustainable, community-first technology together
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700">
              Become a Partner
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-slate-900">
              Download Partner Pack
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 bg-slate-950 text-slate-400">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex flex-wrap justify-center gap-6 mb-6">
            <Link href="/about" className="hover:text-white transition">About</Link>
            <Link href="/ecosystem" className="hover:text-white transition">Ecosystem</Link>
            <Link href="/investors" className="hover:text-white transition">Investors</Link>
            <Link href="/partners" className="hover:text-white transition">Partners</Link>
            <Link href="/careers" className="hover:text-white transition">Careers</Link>
            <Link href="/contact" className="hover:text-white transition">Contact</Link>
          </div>
          <div className="text-sm">
            © 2025 Wynaxa. All rights reserved. | Privacy Policy | Terms of Service
          </div>
        </div>
      </footer>
    </div>
  );
}
