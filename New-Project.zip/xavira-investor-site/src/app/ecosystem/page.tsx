import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function Ecosystem() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-slate-900">Wynaxa</Link>

          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-slate-600 hover:text-slate-900 transition">About</Link>
            <Link href="/ecosystem" className="text-slate-900 font-medium">Ecosystem</Link>
            <Link href="/investors" className="text-slate-600 hover:text-slate-900 transition">Investors</Link>
            <Link href="/partners" className="text-slate-600 hover:text-slate-900 transition">Partners</Link>
            <Link href="/contact" className="text-slate-600 hover:text-slate-900 transition">Contact</Link>
          </div>

          <Button className="bg-emerald-600 hover:bg-emerald-700">
            Investor Access
          </Button>
        </div>
      </nav>

      {/* Header */}
      <section className="py-24 px-6 bg-gradient-to-br from-slate-50 to-white">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6">
            Four products, one connected mission.
          </h1>
          <p className="text-xl text-slate-600">
            Built to empower local economies through technology.
          </p>
        </div>
      </section>

      {/* Wynaxa Pay */}
      <section className="py-24 px-6 bg-gradient-to-br from-purple-50 via-purple-100 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center mb-6">
                <span className="text-4xl">💳</span>
              </div>
              <h2 className="text-4xl font-bold text-purple-900 mb-6">Wynaxa Pay</h2>
              <p className="text-lg text-purple-800 mb-8 leading-relaxed">
                Revolutionary payment system that keeps fees local and transparent.
                Transform every transaction into an interaction that strengthens your community.
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                  <span className="text-purple-900 font-medium">Smart local payments</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                  <span className="text-purple-900 font-medium">Transparent fee structure</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                  <span className="text-purple-900 font-medium">Community reinvestment</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                  <span className="text-purple-900 font-medium">Real-time impact tracking</span>
                </div>
              </div>

              <Button className="bg-purple-600 hover:bg-purple-700">
                Learn More →
              </Button>
            </div>

            <div className="order-1 lg:order-2">
              <div className="w-full h-96 bg-gradient-to-br from-purple-200 to-purple-400 rounded-3xl flex items-center justify-center">
                <span className="text-9xl">💳</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Wynaxa One */}
      <section className="py-24 px-6 bg-gradient-to-br from-blue-50 via-blue-100 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="w-full h-96 bg-gradient-to-br from-blue-200 to-blue-400 rounded-3xl flex items-center justify-center">
                <span className="text-9xl">🏪</span>
              </div>
            </div>

            <div>
              <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mb-6">
                <span className="text-4xl">🏪</span>
              </div>
              <h2 className="text-4xl font-bold text-blue-900 mb-6">Wynaxa One</h2>
              <p className="text-lg text-blue-800 mb-8 leading-relaxed">
                Your unified marketplace for local living. Everything from hospitality to retail
                to unique experiences — all in one beautifully integrated basket.
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-blue-900 font-medium">Unified marketplace for local living</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-blue-900 font-medium">Hospitality, retail, and experiences</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-blue-900 font-medium">Seamless booking and purchasing</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-blue-900 font-medium">Support local businesses</span>
                </div>
              </div>

              <Button className="bg-blue-600 hover:bg-blue-700">
                Learn More →
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Wynaxa Eco */}
      <section className="py-24 px-6 bg-gradient-to-br from-green-50 via-green-100 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center mb-6">
                <span className="text-4xl">🌱</span>
              </div>
              <h2 className="text-4xl font-bold text-green-900 mb-6">Wynaxa Eco</h2>
              <p className="text-lg text-green-800 mb-8 leading-relaxed">
                Circular economy platform that rewards sustainable choices.
                Track your environmental impact and earn rewards for making eco-friendly decisions.
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  <span className="text-green-900 font-medium">Circular economy support</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  <span className="text-green-900 font-medium">Rewards for sustainability</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  <span className="text-green-900 font-medium">Carbon tracking and offset</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  <span className="text-green-900 font-medium">Local environmental initiatives</span>
                </div>
              </div>

              <Button className="bg-green-600 hover:bg-green-700">
                Learn More →
              </Button>
            </div>

            <div className="order-1 lg:order-2">
              <div className="w-full h-96 bg-gradient-to-br from-green-200 to-green-400 rounded-3xl flex items-center justify-center">
                <span className="text-9xl">🌱</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Wynaxa Foundry */}
      <section className="py-24 px-6 bg-gradient-to-br from-orange-50 via-orange-100 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="w-full h-96 bg-gradient-to-br from-orange-200 to-orange-400 rounded-3xl flex items-center justify-center">
                <span className="text-9xl">🔬</span>
              </div>
            </div>

            <div>
              <div className="w-16 h-16 bg-orange-600 rounded-2xl flex items-center justify-center mb-6">
                <span className="text-4xl">🔬</span>
              </div>
              <h2 className="text-4xl font-bold text-orange-900 mb-6">Wynaxa Foundry</h2>
              <p className="text-lg text-orange-800 mb-8 leading-relaxed">
                Innovation lab incubating technology for good. From concept to community rollout,
                we build and test solutions that create lasting positive impact.
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                  <span className="text-orange-900 font-medium">Incubating technology for good</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                  <span className="text-orange-900 font-medium">From concept to community rollout</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                  <span className="text-orange-900 font-medium">R&D for social impact</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                  <span className="text-orange-900 font-medium">Partner collaboration platform</span>
                </div>
              </div>

              <Button className="bg-orange-600 hover:bg-orange-700">
                Learn More →
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-6 bg-slate-900 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Be Part of the Ecosystem</h2>
          <p className="text-xl text-slate-300 mb-8">
            Join thousands of businesses and communities already benefiting from
            the Wynaxa ecosystem.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700">
              Become a Partner
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-slate-900">
              Contact Us
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 bg-slate-950 text-slate-400">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex flex-wrap justify-center gap-6 mb-6">
            <Link href="/about" className="hover:text-white transition">About</Link>
            <Link href="/ecosystem" className="hover:text-white transition">Ecosystem</Link>
            <Link href="/investors" className="hover:text-white transition">Investors</Link>
            <Link href="/partners" className="hover:text-white transition">Partners</Link>
            <Link href="/contact" className="hover:text-white transition">Contact</Link>
          </div>
          <div className="text-sm">
            © 2025 Wynaxa. All rights reserved. | Privacy Policy | Terms of Service
          </div>
        </div>
      </footer>
    </div>
  );
}
